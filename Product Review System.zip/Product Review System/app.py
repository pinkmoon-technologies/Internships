from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Secret key for flash messages

# Store users dynamically in a dictionary
users = {}

# Simulated product data
products = [
    {"id": 1, "name": "Wireless Headphones", "description": "Premium over-ear headphones with noise-cancelling features.", "price": 120, "image": "https://i.ibb.co/tTQZKzyr/i1.jpg", "reviews": [], "average_rating": 0},
    {"id": 2, "name": "Smartphone", "description": "Latest model with a 6.5-inch OLED display, 128GB storage, and 12MP camera.", "price": 899, "image": "https://i.ibb.co/HTwdHXNn/i2.jpg", "reviews": [], "average_rating": 0},
    {"id": 3, "name": "Gaming Laptop", "description": "High-performance laptop with NVIDIA RTX graphics and a 144Hz display.", "price": 1500, "image": "https://i.ibb.co/4gM2Kjkf/i3.jpg", "reviews": [], "average_rating": 0},
    {"id": 4, "name": "Smartwatch", "description": "Track your fitness and stay connected with this sleek smartwatch.", "price": 250, "image": "https://i.ibb.co/tpL0Q3j1/i4.jpg", "reviews": [], "average_rating": 0},
    {"id": 5, "name": "Bluetooth Speaker", "description": "Portable Bluetooth speaker with a waterproof design and 20-hour battery life.", "price": 70, "image": "https://i.ibb.co/gM1yvGjc/i5.jpg", "reviews": [], "average_rating": 0},
    {"id": 6, "name": "Camera", "description": "A camera is a device that captures photos and videos with varying levels of quality and functionality.", "price": 100, "image": "https://i.ibb.co/wNB49x2Q/i6.jpg", "reviews": [], "average_rating": 0},
    {"id": 7, "name": "Projector", "description": "A projector is a device that displays images or videos on a large screen by projecting light.", "price": 150, "image": "https://i.ibb.co/ymdwjZ1h/i7.webp", "reviews": [], "average_rating": 0},
    {"id": 8, "name": "Printer", "description": "A printer is a device that transfers digital documents or images onto paper.", "price": 170, "image": "https://i.ibb.co/JFSj5grL/i8.jpg", "reviews": [], "average_rating": 0},
    {"id": 9, "name": "Smart TV", "description": "A Smart TV is a television with internet connectivity, allowing access to streaming services, apps, and web browsing.", "price": 270, "image": "https://i.ibb.co/wNQ1Xbr0/i9.jpg", "reviews": [], "average_rating": 0},
]


# Helper function to calculate average rating for a product
def calculate_average_rating(reviews):
    if len(reviews) == 0:
        return 0
    total_rating = sum([review['rating'] for review in reviews])
    return total_rating / len(reviews)

@app.route('/')
def index():
    # Get the current logged-in user's username from session
    username = session.get('username')
    return render_template('index.html', products=products, username=username)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    # Check if user is logged in
    if 'username' not in session:
        flash('You need to login first to view the product details.', 'warning')
        return redirect(url_for('login'))  # Redirect to login page

    product = next((prod for prod in products if prod['id'] == product_id), None)
    if product is None:
        return redirect(url_for('index'))

    # Calculate average rating for product
    product['average_rating'] = calculate_average_rating(product['reviews'])
    
    username = session.get('username')
    return render_template('product_detail.html', product=product, username=username)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username in users and users[username]['password'] == password:
            session['username'] = username  # Save username in session
            flash(f'Login successful, Welcome {username}!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password', 'danger')

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username in users:
            flash('Username already taken. Please choose a different one.', 'danger')
            return redirect(url_for('register'))
        
        # Register the new user
        users[username] = {"password": password, "name": username}
        flash(f'Account created successfully, Welcome {username}!', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('username', None)  # Remove username from session
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/review/<int:product_id>', methods=['GET', 'POST'])
def review(product_id):
    product = next((prod for prod in products if prod['id'] == product_id), None)
    if product is None:
        return redirect(url_for('index'))

    if request.method == 'POST':
        rating = int(request.form['rating'])
        comment = request.form['comment']
        review = {
            'user': request.form['username'],  # User is passed through form
            'rating': rating,
            'comment': comment,
            'date': datetime.now(),
            'comments': []
        }
        product['reviews'].append(review)

        # Recalculate the average rating after the review
        product['average_rating'] = calculate_average_rating(product['reviews'])

        flash('Review added successfully', 'success')
        return redirect(url_for('index'))

    return render_template('add_review.html', product=product)

@app.route('/comment/<int:product_id>/<int:review_index>', methods=['POST'])
def comment(product_id, review_index):
    product = next((prod for prod in products if prod['id'] == product_id), None)
    if product is None or review_index >= len(product['reviews']):
        return redirect(url_for('index'))

    comment = request.form['comment']
    product['reviews'][review_index]['comments'].append({
        'user': request.form['username'],  # User is passed through form
        'comment': comment,
        'date': datetime.now()
    })

    flash('Comment added successfully', 'success')
    return redirect(url_for('product_detail', product_id=product_id))

if __name__ == '__main__':
    app.run(debug=True)
