from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime, timedelta
import os

# Initialize Flask app
app = Flask(__name__)
app.secret_key = 'your_secret_key'

# File paths for storing data
USER_FILE = 'users.txt'
AD_FILE = 'ads.txt'

# Utility functions for reading and writing files
def read_file(file_name):
    if os.path.exists(file_name):
        with open(file_name, 'r') as f:
            return f.read().splitlines()
    return []

def write_file(file_name, data):
    with open(file_name, 'a') as f:
        f.write(data + "\n")

# Routes

# Home page showing all active ads
@app.route('/')
def home():
    ads = read_file(AD_FILE)
    active_ads = []

    # Check ad expiration (ads expire after 30 days)
    for ad in ads:
        title, description, category, posted_at = ad.split(",")
        posted_at = datetime.strptime(posted_at, "%Y-%m-%d %H:%M:%S")
        expires_at = posted_at + timedelta(days=30)

        if datetime.utcnow() < expires_at:
            active_ads.append(ad)
    
    return render_template('home.html', ads=active_ads)

# Login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users = read_file(USER_FILE)

        for user in users:
            stored_username, stored_password = user.split(",")
            if stored_username == username and stored_password == password:
                return redirect(url_for('home'))
        flash('Invalid credentials!', 'danger')
    return render_template('login.html')

# Signup page
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users = read_file(USER_FILE)

        # Check if username already exists
        for user in users:
            stored_username, _ = user.split(",")
            if stored_username == username:
                flash('Username already exists!', 'danger')
                return redirect(url_for('signup'))

        # Save the new user
        write_file(USER_FILE, f"{username},{password}")
        flash('Account created successfully!', 'success')
        return redirect(url_for('login'))
    return render_template('signup.html')

# Post ad page
@app.route('/post_ad', methods=['GET', 'POST'])
def post_ad():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        category = request.form['category']
        posted_at = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        ad_data = f"{title},{description},{category},{posted_at}"

        write_file(AD_FILE, ad_data)
        flash('Ad posted successfully!', 'success')
        return redirect(url_for('home'))
    
    return render_template('post_ad.html')

# Search page
@app.route('/search', methods=['POST'])
def search():
    query = request.form['search']
    ads = read_file(AD_FILE)
    results = [ad for ad in ads if query.lower() in ad.lower()]
    return render_template('search_results.html', ads=results)

# Report ad page
@app.route('/report_ad/<int:ad_id>')
def report_ad(ad_id):
    ads = read_file(AD_FILE)
    if 0 <= ad_id < len(ads):
        ad = ads[ad_id]
        # In a real-world app, you'd store this in a separate report file or database
        flash(f"Ad '{ad.split(',')[0]}' has been reported.", 'warning')
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
