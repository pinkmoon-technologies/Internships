from flask import Flask, render_template, request, redirect, url_for, session, flash
import random
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# In-memory storage for users and their data
users = {}

# Dummy data for sessions and tips
meditation_sessions = [
    {'id': 1, 'name': 'Morning Calm', 'duration': 10, 'description': 'A short 10-minute session to start your day with calmness.', 'image_url': 'https://www.koreaetour.com/wp-content/uploads/2012/06/%EC%95%84%EC%B9%A8%EA%B3%A0%EC%9A%94%EC%88%98%EB%AA%A9%EC%9B%90-6.jpg'},
    {'id': 2, 'name': 'Mindful Breathing', 'duration': 15, 'description': 'A 15-minute session focusing on breath awareness.', 'image_url': 'https://mindalcove.com/blog/wp-content/uploads/elementor/thumbs/A-Guide-to-Mindful-Breathing-Blog-Feature-qcsa1di5g8bryxyw4v30ttqb2tkanjlxr79sldxtk0.jpg'},
    {'id': 3, 'name': 'Evening Relaxation', 'duration': 20, 'description': 'A relaxing 20-minute meditation to wind down in the evening.', 'image_url': 'https://blog.lilyandval.com/wp-content/uploads/2015/11/unwind_Header.jpg'}
]

wellness_tips = [
    "Drink plenty of water throughout the day.",
    "Incorporate deep breathing exercises into your daily routine.",
    "Get at least 7-8 hours of sleep each night.",
    "Stay connected with nature, even if it's a short walk outside.",
    "Practice gratitude to improve mental well-being."
]

@app.route('/')
def home():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('home.html', sessions=meditation_sessions)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username in users:
            flash('Username already exists. Please choose another.', 'danger')
            return redirect(url_for('register'))

        users[username] = {'password': password, 'mood_data': []}
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = users.get(username)
        if user and user['password'] == password:
            session['username'] = username
            flash('Login successful!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Invalid username or password. Please try again.', 'danger')

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('Logged out successfully.', 'info')
    return redirect(url_for('login'))

@app.route('/meditation/<int:session_id>')
def meditation(session_id):
    if 'username' not in session:
        return redirect(url_for('login'))

    session_info = next((session for session in meditation_sessions if session['id'] == session_id), None)
    if not session_info:
        flash("Meditation session not found.", 'danger')
        return redirect(url_for('home'))

    return render_template('meditation.html', session=session_info)

@app.route('/complete_meditation/<int:session_id>', methods=['POST'])
def complete_meditation(session_id):
    if 'username' not in session:
        return redirect(url_for('login'))

    session_info = next((session for session in meditation_sessions if session['id'] == session_id), None)
    if not session_info:
        flash("Meditation session not found.", 'danger')
        return redirect(url_for('home'))

    mood = request.form.get('mood')
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    users[session['username']]['mood_data'].append({'session_name': session_info['name'], 'mood': mood, 'timestamp': timestamp})
    flash(f"Great job on completing '{session_info['name']}'!", 'success')
    return redirect(url_for('progress'))

@app.route('/progress')
def progress():
    if 'username' not in session:
        return redirect(url_for('login'))

    user_moods = users[session['username']]['mood_data']
    return render_template('progress.html', mood_data=user_moods)

@app.route('/wellness_tips')
def wellness_tips_page():
    if 'username' not in session:
        return redirect(url_for('login'))

    tip = random.choice(wellness_tips)
    return render_template('wellness_tips.html', tip=tip)

@app.route('/set_reminder', methods=['POST'])
def set_reminder():
    if 'username' not in session:
        return redirect(url_for('login'))

    reminder_time = request.form.get('reminder_time')
    if reminder_time:
        users[session['username']]['reminder_time'] = reminder_time
        flash(f"Reminder set for {reminder_time}!", 'info')
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
