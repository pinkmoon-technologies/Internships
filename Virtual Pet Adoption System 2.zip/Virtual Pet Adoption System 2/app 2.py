from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Static Pet Data (No database)
pets = [
    {
        "id": 1,
        "name": "Max",
        "species": "Dog",
        "age": 3,
        "description": "A playful and friendly dog.",
        "image_url": "/static/images/pet1.jpg",
        "adoption_status": "Available"
    },
    {
        "id": 2,
        "name": "Bella",
        "species": "Cat",
        "age": 2,
        "description": "A calm and affectionate cat.",
        "image_url": "/static/images/pet2.jpg",
        "adoption_status": "Available"
    },
    {
        "id": 3,
        "name": "Charlie",
        "species": "Rabbit",
        "age": 1,
        "description": "A curious and active rabbit.",
        "image_url": "/static/images/pet3.jpg",
        "adoption_status": "Available"
    },
    {
        "id": 4,
        "name": "Luna",
        "species": "Dog",
        "age": 4,
        "description": "A loyal and energetic dog.",
        "image_url": "/static/images/pet4.jpg",
        "adoption_status": "Available"
    },
    {
        "id": 5,
        "name": "Oliver",
        "species": "Cat",
        "age": 3,
        "description": "A playful and curious cat.",
        "image_url": "/static/images/pet5.jpg",
        "adoption_status": "Available"
    },
    {
        "id": 6,
        "name": "Milo",
        "species": "Hamster",
        "age": 0.5,
        "description": "A small, friendly hamster.",
        "image_url": "/static/images/pet6.jpg",
        "adoption_status": "Available"
    },
    {
        "id": 7,
        "name": "Rocky",
        "species": "Bird",
        "age": 2,
        "description": "A talkative and social bird.",
        "image_url": "/static/images/pet7.jpg",
        "adoption_status": "Available"
    },
    {
        "id": 8,
        "name": "Nala",
        "species": "Cat",
        "age": 5,
        "description": "A calm and elegant cat.",
        "image_url": "/static/images/pet8.jpg",
        "adoption_status": "Available"
    },
    {
        "id": 9,
        "name": "Coco",
        "species": "Rabbit",
        "age": 2,
        "description": "A fluffy and affectionate rabbit.",
        "image_url": "/static/images/pet9.jpg",
        "adoption_status": "Available"
    }
]

# Temporary in-memory storage for reviews (with default reviews for each pet)
# Temporary in-memory storage for reviews (with expanded reviews for each pet)
reviews_db = {
    1: [
        "⭐⭐⭐⭐⭐ Max is an amazing dog! He has a super friendly personality and loves to play fetch. He's very energetic and enjoys outdoor activities. He is always so excited when I come home!",
        "⭐⭐⭐⭐⭐ Max is such a great companion! He's loyal, playful, and very affectionate. Every time I take him for a walk, he makes everyone smile.",
        "⭐⭐⭐⭐⭐ My family loves Max! He's always so gentle with kids and other pets. His playful nature is contagious and he brightens up every day."
    ],
    2: [
        "⭐⭐⭐⭐⭐ Bella is the sweetest cat I've ever met. She's very affectionate and loves to curl up on your lap. She's also very calm, making her perfect for anyone who loves a relaxed companion.",
        "⭐⭐⭐⭐⭐ Bella is a joy to be around. She's very quiet but always seems to know when you need some comfort. She’s definitely a cuddle expert!",
        "⭐⭐⭐⭐⭐ Bella is a calm and graceful cat. Her purring is so soothing, and she loves to sit in sunny spots by the window, watching the world go by."
    ],
    3: [
        "⭐⭐⭐⭐⭐ Charlie is an incredibly curious rabbit. He loves exploring and hopping around the house. He's also very friendly and doesn't mind being held for short periods.",
        "⭐⭐⭐⭐⭐ Charlie is so fun to have around. He loves playing with toys and always gets excited when I bring out fresh veggies. His soft fur is just adorable.",
        "⭐⭐⭐⭐⭐ Charlie is an adventurous rabbit! He enjoys running around and exploring new places, but he’s also great for cuddling during the evenings."
    ],
    4: [
        "⭐⭐⭐⭐⭐ Luna is such a loyal dog! She’s always by my side and is incredibly protective of the family. Her energy and enthusiasm are contagious, and she loves outdoor adventures.",
        "⭐⭐⭐⭐⭐ Luna is a sweet and energetic dog. She loves to play fetch and run around, but she’s also calm when it’s time to relax. She's perfect for an active family.",
        "⭐⭐⭐⭐⭐ Luna is so loving! She's always the first to greet us when we come home, and her tail never stops wagging. She’s the best companion for hikes or even just lazy days at home."
    ],
    5: [
        "⭐⭐⭐⭐⭐ Oliver is such a playful cat! He’s always chasing after toys and pouncing on anything that moves. He's very curious and loves to explore every nook and cranny of the house.",
        "⭐⭐⭐⭐⭐ Oliver is a sweet and curious cat. He’s very active and loves playing with string toys or just chasing the laser pointer. His big eyes are so expressive!",
        "⭐⭐⭐⭐⭐ Oliver is a very charming and playful cat. He loves being in the middle of everything and is very friendly with other pets and people."
    ],
    6: [
        "⭐⭐⭐⭐⭐ Milo is a delightful little hamster. He's so easy to care for and loves running on his wheel. He’s very curious and loves exploring his cage.",
        "⭐⭐⭐⭐⭐ Milo is a great pet for small spaces. He’s friendly, playful, and always exploring his environment. I love watching him run on his wheel.",
        "⭐⭐⭐⭐⭐ Milo is so cute and cuddly! He’s very gentle and enjoys sitting in my hand, making him a perfect companion for anyone with a busy schedule."
    ],
    7: [
        "⭐⭐⭐⭐⭐ Rocky is an amazing bird! He’s very talkative and loves mimicking sounds. He’s also very social and loves spending time with us outside of his cage.",
        "⭐⭐⭐⭐⭐ Rocky is such a fun bird! He loves to interact with people and is very curious about everything. He can even mimic simple words and sounds!",
        "⭐⭐⭐⭐⭐ Rocky is a very talkative bird and loves to whistle. He brings so much joy to the house with his antics and playful nature."
    ],
    8: [
        "⭐⭐⭐⭐⭐ Nala is an elegant and calm cat. She’s very graceful and loves to observe the world from high vantage points. She’s a perfect lap cat and enjoys curling up for naps.",
        "⭐⭐⭐⭐⭐ Nala is a relaxed and sophisticated cat. She enjoys lounging around and occasionally chasing after a toy, but most of the time she prefers to stay in her favorite resting spot.",
        "⭐⭐⭐⭐⭐ Nala is so gentle and calm. She enjoys basking in the sun and watching birds outside. She’s a great companion for a quiet home."
    ],
    9: [
        "⭐⭐⭐⭐⭐ Coco is a fluffy rabbit who loves cuddles! She’s very soft and gentle, and she enjoys hopping around the yard and nibbling on fresh greens.",
        "⭐⭐⭐⭐⭐ Coco is a wonderful pet! She’s so affectionate and loves being petted. She’s also very curious and enjoys exploring new places.",
        "⭐⭐⭐⭐⭐ Coco is a calm and fluffy rabbit. She loves lounging around in her favorite spot but is also very playful when the mood strikes."
    ]
}


# Route for Home page (Pet Listing)
@app.route('/')
def home():
    return render_template('index.html', pets=pets)

# Route for Pet Details
@app.route('/pet/<int:id>')
def pet_details(id):
    pet = next((pet for pet in pets if pet["id"] == id), None)
    return render_template('pet_details.html', pet=pet)

# Route for Adoption Application
@app.route('/adopt/<int:id>', methods=['GET', 'POST'])
def adopt(id):
    pet = next((pet for pet in pets if pet["id"] == id), None)
    if request.method == 'POST':
        # Save the adoption application details
        user_name = request.form.get('name')
        user_email = request.form.get('email')
        pet["adoption_status"] = "Adopted"
        return render_template('adoption_confirmation.html', pet=pet, user_name=user_name, user_email=user_email)
    return render_template('adoption_form.html', pet=pet)

# Route for Reviews (only displaying default reviews)
@app.route('/reviews/<int:id>', methods=['GET'])
def reviews(id):
    pet = next((pet for pet in pets if pet["id"] == id), None)

    # If there are no reviews for the pet yet, initialize an empty list (though this shouldn't happen with default reviews)
    if id not in reviews_db:
        reviews_db[id] = []

    return render_template('reviews.html', pet=pet, reviews=reviews_db.get(id, []))

if __name__ == '__main__':
    app.run(debug=True)
