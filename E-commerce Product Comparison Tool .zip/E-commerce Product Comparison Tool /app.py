from flask import Flask, render_template, request, redirect, url_for, session
import random

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Required for sessions

# Mock data simulating responses from different e-commerce platforms
mock_data = {
    'Laptop': [
        {'platform': 'Amazon', 'price': 899.99, 'rating': 4.5, 'features': ['Intel i7', '16GB RAM', '512GB SSD', '15.6" Display']},
        {'platform': 'eBay', 'price': 850.00, 'rating': 4.4, 'features': ['Intel i7', '8GB RAM', '512GB SSD', '14" Display']},
        {'platform': 'BestBuy', 'price': 950.00, 'rating': 4.6, 'features': ['Intel i7', '16GB RAM', '1TB SSD', '15.6" Display']}
    ],
    'Phone': [
        {'platform': 'Amazon', 'price': 699.99, 'rating': 4.7, 'features': ['6.1" Display', '128GB Storage', '12MP Camera', 'A14 Bionic Chip']},
        {'platform': 'eBay', 'price': 680.00, 'rating': 4.5, 'features': ['6.1" Display', '64GB Storage', '12MP Camera', 'A14 Bionic Chip']},
        {'platform': 'BestBuy', 'price': 720.00, 'rating': 4.8, 'features': ['6.1" Display', '128GB Storage', '12MP Camera', 'A14 Bionic Chip']}
    ],
    'Tv': [
        {'platform': 'Amazon', 'price': 300.99, 'rating': 4.5, 'features': ['103 cm" Display', '2GB Storage', 'HDMI PORTS:2|2 USB Ports', 'Operating system:Andriod']},
        {'platform': 'eBay', 'price': 320.00, 'rating': 4.3, 'features': ['103" Display', 'HDMI PORTS:2|2 USB Ports', 'Operating system:Andriod']},
        {'platform': 'BestBuy', 'price': 310.00, 'rating': 4.7, 'features': ['103" Display', 'HDMI PORTS:2|2 USB Ports', 'Operating system:Andriod']}
    ],
    'Tabs': [
        {'platform': 'Amazon', 'price': 200.99, 'rating': 4.7, 'features': ['14.1" Display', '128GB Storage', '12MP Camera', 'A14 Bionic Chip']},
        {'platform': 'eBay', 'price': 250.00, 'rating': 4.5, 'features': ['14.1" Display', '64GB Storage', '12MP Camera', 'A14 Bionic Chip']},
        {'platform': 'BestBuy', 'price': 225.00, 'rating': 4.8, 'features': ['14.1" Display', '128GB Storage', '12MP Camera', 'A14 Bionic Chip']}
    ],
    'Watch': [
        {'platform': 'Amazon', 'price': 150.99, 'rating': 4.7, 'features': ['1.3" Display', '1GB Storage', '2GB Ram', 'Andriod']},
        {'platform': 'eBay', 'price': 170.00, 'rating': 4.5, 'features': ['1.3" Display', '1GB Storage', '2GB Ram', 'Andriod']},
        {'platform': 'BestBuy', 'price': 140.00, 'rating': 4.8, 'features': ['1.3" Display', '1GB Storage', '2GB Ram', 'Andriod']}
    ],
    'Headphones': [
        {'platform': 'Amazon', 'price': 199.99, 'rating': 4.4, 'features': ['Noise Cancelling', '20 Hours Battery', 'Bluetooth 5.0']},
        {'platform': 'eBay', 'price': 180.00, 'rating': 4.3, 'features': ['Noise Cancelling', '15 Hours Battery', 'Bluetooth 4.2']},
        {'platform': 'BestBuy', 'price': 220.00, 'rating': 4.6, 'features': ['Noise Cancelling', '30 Hours Battery', 'Bluetooth 5.0']}
    ]
}

# Mock user login (to be replaced with real authentication logic)
users = {'student1': 'password1'}

# Route to ensure user is logged in before accessing the index page
@app.route('/')
def index():
    if 'user' not in session:  # Check if user is logged in
        return redirect(url_for('login'))  # Redirect to login if not logged in
    categories = list(mock_data.keys())  # Available categories to display in dropdown
    return render_template('index.html', categories=categories)

@app.route('/compare', methods=['POST'])
def compare():
    if 'user' not in session:  # Protect this route too
        return redirect(url_for('login'))  # Redirect to login if not logged in

    if request.method == 'POST':
        product_name = request.form['product_name']
        product_category = request.form['category']

        # Validate category and product data
        if product_category not in mock_data:
            return render_template('index.html', categories=list(mock_data.keys()), error="Invalid category selected.")
        
        # Get relevant product data for comparison
        product_comparison = mock_data[product_category]

        # Return the comparison result page with data
        return render_template('comparison_result.html', product_name=product_name, product_comparison=product_comparison)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if users.get(username) == password:
            session['user'] = username  # Store the logged-in user in the session
            return redirect(url_for('index'))  # Redirect to index page after login
        else:
            return render_template('login.html', error="Invalid credentials.")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)  # Remove user from session
    return redirect(url_for('login'))  # Redirect to login page after logout

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username in users:
            return render_template('register.html', error="Username already exists.")
        
        # Register the new user
        users[username] = password
        return redirect(url_for('login'))  # After registering, redirect to login
    
    return render_template('register.html')

if __name__ == '__main__':
    app.run(debug=True)
