from flask import Flask, render_template, request, redirect, url_for, session, flash
import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'

# Temporary data storage (in-memory)
users = {}  # Format: {username: {'password': 'password', 'id': user_id, 'messages': []}}
ads = []  # List of ads, each ad is a dictionary
current_user = None  # For tracking current logged-in user
ad_id_counter = 1  # Unique ID for each ad

# Home route (display all active ads)
@app.route('/')
def index():
    current_time = datetime.datetime.now()

    # Convert string expiration_date to datetime object before comparison
    active_ads = []
    for ad in ads:
        # Convert only if it's a string
        if isinstance(ad['expiration_date'], str):
            ad['expiration_date'] = datetime.datetime.strptime(ad['expiration_date'], '%Y-%m-%d')
        
        # Now compare properly
        if ad['expiration_date'] > current_time:
            active_ads.append(ad)

    return render_template('index.html', ads=active_ads, current_user=current_user)

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    global current_user
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username in users and users[username]['password'] == password:
            current_user = username
            return redirect(url_for('index'))
        else:
            return "Invalid credentials, please try again."

    return render_template('login.html')

# Logout route
@app.route('/logout')
def logout():
    global current_user
    current_user = None
    return redirect(url_for('index'))

# Post Ad route
@app.route('/post-ad', methods=['GET', 'POST'])
def post_ad():
    global ad_id_counter
    if not current_user:
        return redirect(url_for('login'))

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        category = request.form['category']
        price = request.form['price']
        expiration_date = datetime.datetime.now() + datetime.timedelta(days=7)
        # Format the expiration_date as 'YYYY-MM-DD'
        formatted_expiration_date = expiration_date.strftime('%Y-%m-%d')
        
        # Create new ad
        ad = {
            'id': ad_id_counter,
            'title': title,
            'description': description,
            'category': category,
            'price': price,
            'user': current_user,
            'expiration_date': formatted_expiration_date,
            'reported': False
        }

        ads.append(ad)
        ad_id_counter += 1  # Increment ad ID for next ad
        return redirect(url_for('index'))

    return render_template('post_ad.html')

# Search Ads route
@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        keyword = request.form['keyword']
        matching_ads = [ad for ad in ads if keyword.lower() in ad['title'].lower() or keyword.lower() in ad['description'].lower()]
        return render_template('search.html', ads=matching_ads)

    return render_template('search.html', ads=[])

# Ad Details Route
@app.route('/ad/<int:ad_id>')
def ad_details(ad_id):
    ad = next((ad for ad in ads if ad['id'] == ad_id), None)
    if ad:
        return render_template('ad_detail.html', ad=ad)
    return "Ad not found", 404

# Report Ad route (GET)
@app.route('/report/<int:ad_id>', methods=['GET'])
def show_report_form(ad_id):
    # Find the ad by its ID
    ad = next((ad for ad in ads if ad['id'] == ad_id), None)
    
    if ad:
        return render_template('report_ad.html', ad=ad)
    else:
        return "Ad not found", 404

# Report Ad route (POST)
@app.route('/report_ad/<int:ad_id>', methods=['POST'])
def report_ad_action(ad_id):
    reason = request.form['reason']
    additional_info = request.form['additional_info']
    
    # Handle the report logic here (e.g., save the report)
    print(f"Report for Ad {ad_id}: Reason - {reason}, Additional Info - {additional_info}")
    
    # Flash a success message to inform the user
    flash('Your report has been successfully submitted!', 'success')
    
    # Redirect back to the index page after submission
    return redirect(url_for('index'))


# Direct Messaging route
@app.route('/message/<string:recipient>', methods=['GET', 'POST'])
def message(recipient):
    global users
    if not current_user:
        return redirect(url_for('login'))

    if recipient not in users:
        return "User not found", 404

    if request.method == 'POST':
        message_text = request.form['message']
        # Add message to both sender's and recipient's message list
        users[current_user]['messages'].append({'to': recipient, 'message': message_text, 'time': datetime.datetime.now()})
        users[recipient]['messages'].append({'to': current_user, 'message': message_text, 'time': datetime.datetime.now()})
        return redirect(url_for('message', recipient=recipient))

    return render_template('messaging.html', recipient=recipient, messages=users[current_user]['messages'])

# User Registration route (simplified)
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users:
            return "User already exists, please log in."
        
        user_id = len(users) + 1  # Assign a unique user ID
        users[username] = {'password': password, 'id': user_id, 'messages': []}
        return redirect(url_for('login'))
    
    return render_template('register.html')

if __name__ == "__main__":
    app.run(debug=True)
