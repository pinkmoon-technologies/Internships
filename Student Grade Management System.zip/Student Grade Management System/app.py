from flask import Flask, render_template, request, redirect, url_for, jsonify
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)

# Temporary in-memory data storage
students = []
subjects = []

class Student:
    def __init__(self, student_id, name):
        self.student_id = student_id
        self.name = name
        self.grades = {}

    def add_grade(self, subject, grade):
        self.grades[subject] = grade

    def get_average(self):
        return sum(self.grades.values()) / len(self.grades) if self.grades else 0

@app.route('/')
def index():
    return render_template('index.html', students=students, subjects=subjects)

@app.route('/register_student', methods=['GET', 'POST'])
def register_student():
    if request.method == 'POST':
        student_id = request.form['student_id']
        name = request.form['name']
        
        # Check if student ID already exists
        for student in students:
            if student.student_id == student_id:
                return render_template('register_student.html', error="Student ID already exists!")

        student = Student(student_id, name)
        students.append(student)
        return redirect(url_for('index'))
    
    return render_template('register_student.html', error=None)

@app.route('/remove_student/<student_id>')
def remove_student(student_id):
    global students
    students = [student for student in students if student.student_id != student_id]
    return redirect(url_for('index'))

@app.route('/register_subject', methods=['GET', 'POST'])
def register_subject():
    if request.method == 'POST':
        subject = request.form['subject']

        # Check if subject already exists
        if subject in subjects:
            return render_template('register_subject.html', error="Subject already exists!")
        
        subjects.append(subject)
        return redirect(url_for('index'))
    return render_template('register_subject.html', error=None)

@app.route('/remove_subject/<subject>')
def remove_subject(subject):
    global subjects
    subjects = [s for s in subjects if s != subject]
    return redirect(url_for('index'))

@app.route('/input_grades', methods=['GET', 'POST'])
def input_grades():
    if request.method == 'POST':
        student_id = request.form['student_id']
        grades = {subject: min(10, float(request.form[subject])) for subject in subjects}  # max grade = 10
        for student in students:
            if student.student_id == student_id:
                for subject, grade in grades.items():
                    student.add_grade(subject, grade)
        return redirect(url_for('index'))
    return render_template('input_grades.html', students=students, subjects=subjects)

@app.route('/student_detail/<student_id>')
def student_detail(student_id):
    student = next((s for s in students if s.student_id == student_id), None)
    if student:
        chart_url = generate_student_performance_graph(student)
        average_grade = student.get_average()  # Calculate the average grade
        return render_template('student_detail.html', student=student, subjects=subjects, chart_url=chart_url, average_grade=average_grade)
    return redirect(url_for('index'))

def generate_student_performance_graph(student):
    fig, ax = plt.subplots(figsize=(8, 5))

    # Data for the student's performance graph
    subjects = list(student.grades.keys())
    grades = list(student.grades.values())

    ax.plot(subjects, grades, label="Grades", marker='o', color='b', linestyle='-', linewidth=2)

    ax.set_xlabel('Subjects')
    ax.set_ylabel('Grades')
    ax.set_title(f'{student.name}\'s Performance')
    ax.set_ylim(0, 10)  # Ensure grade is between 0 and 10
    ax.grid(True)

    # Save the plot to a BytesIO object and encode it as a base64 string
    img = io.BytesIO()
    plt.tight_layout()
    plt.savefig(img, format='png')
    img.seek(0)
    chart_url = base64.b64encode(img.getvalue()).decode('utf8')
    return chart_url


@app.route('/generate_report')
def generate_report():
    table_data = []
    for student in students:
        avg_grade = student.get_average()
        table_data.append([student.student_id, student.name, avg_grade] + list(student.grades.values()))
    headers = ['Student ID', 'Name', 'Average Grade'] + subjects
    return render_template('report.html', table_data=table_data, headers=headers)

@app.route('/generate_chart')
def generate_chart():
    # Create a chart with line graph
    fig, ax = plt.subplots(figsize=(10, 6))

    # Generate data for the line graph
    for idx, subject in enumerate(subjects):
        subject_grades = [student.grades.get(subject, 0) for student in students]
        ax.plot([student.name for student in students], subject_grades, label=subject, marker='o')

    ax.set_xlabel('Student')
    ax.set_ylabel('Grade')
    ax.set_title('Subject-wise Grades of Students')
    ax.legend()

    # Save the plot to a BytesIO object and encode it as a base64 string
    img = io.BytesIO()
    plt.tight_layout()
    plt.savefig(img, format='png')
    img.seek(0)
    chart_url = base64.b64encode(img.getvalue()).decode('utf8')

    return render_template('chart.html', chart_url=chart_url)

if __name__ == '__main__':
    app.run(debug=True)
