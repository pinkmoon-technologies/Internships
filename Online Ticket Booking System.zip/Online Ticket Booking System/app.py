from flask import Flask, render_template, request, redirect, url_for, session
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Secret key for session management

# Sample event/movie data
events = [
    {
        "id": 1,
        "name": "Starlight Music Festival",
        "available": True,
        "images": ["https://i.ibb.co/LzP8QXFF/a-1.jpg", "https://i.ibb.co/wZZfc5D0/a-2.jpg", "https://i.ibb.co/9HHrGLT3/a-3.jpg"]
    },
    {
        "id": 2,
        "name": "The Grand Illusionist Show",
        "available": True,
        "images": ["https://i.ibb.co/2Ys5G7Tp/b-1.jpg", "https://i.ibb.co/7xqZGQ09/b-2.jpg", "https://i.ibb.co/SX2q5V55/b-3.jpg"]
    },
    {
        "id": 2,
        "name": "Cinematic Nights",
        "available": True,
        "images": ["https://i.ibb.co/ym2Qfhd2/c-1.jpg", "https://i.ibb.co/svwSyGmg/c-2.jpg"]
    }
]

# Sample seat availability for each event
seats = {
    1: {"total": 50, "booked": 0},
    2: {"total": 100, "booked": 0},
    3: {"total": 75, "booked": 0}
}

# In-memory "database" for users and bookings
users = {}
bookings = []

# Home route displaying available events/movies
@app.route('/')
def index():
    # Update the availability status of each event based on booked seats
    for event in events:
        event_id = event['id']
        available_seats = seats[event_id]['total'] - seats[event_id]['booked']
        event['available'] = available_seats > 0  # If seats are left, mark as available
    return render_template('index.html', events=events, user=session.get('user'))

# Route for user login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        username = request.form['username']
        session['user'] = {"username": username, "email": email}  # Store user info in session
        if email not in users:
            users[email] = {"username": username, "email": email}
        return redirect(url_for('index'))
    return render_template('login.html')

# Route for user logout
@app.route('/logout')
def logout():
    session.pop('user', None)  # Remove user from session
    return redirect(url_for('index'))

# Route to handle selecting showtimes and seats
@app.route('/showtimes/<int:event_id>', methods=['GET', 'POST'])
def showtimes(event_id):
    event = next((e for e in events if e["id"] == event_id), None)
    available_seats = seats.get(event_id, {}).get("total", 0) - seats.get(event_id, {}).get("booked", 0)
    
    if request.method == 'POST':
        # Simulate seat selection and ticket booking
        num_tickets = int(request.form['num_tickets'])
        
        if num_tickets <= available_seats:
            seats[event_id]["booked"] += num_tickets
            booking = {
                "event": event["name"],
                "num_tickets": num_tickets,
                "user": request.form['name'],
                "email": request.form['email'],
                "showtime": request.form['showtime']
            }
            bookings.append(booking)
            return redirect(url_for('booking', booking_id=len(bookings) - 1))
        else:
            return render_template('showtimes.html', event=event, error="Not enough seats available", available_seats=available_seats)

    return render_template('showtimes.html', event=event, available_seats=available_seats)

# Route to confirm booking
@app.route('/booking/<int:booking_id>')
def booking(booking_id):
    booking = bookings[booking_id]
    return render_template('booking.html', booking=booking)

if __name__ == '__main__':
    app.run(debug=True)
