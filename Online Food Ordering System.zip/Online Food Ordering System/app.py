from flask import Flask, render_template, request, redirect, url_for, session, flash
from datetime import datetime
import random

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Used to encrypt session data

# Mock Data
restaurants = {
    'Le Story RESTAURANT': [
        {'id': 1, 'name': 'Pizza', 'category': 'Main Course', 'price': 12.99, 'image': 'https://i.ibb.co/bR3vLXNk/img1.jpg'},
        {'id': 2, 'name': 'Burger', 'category': 'Main Course', 'price': 8.49, 'image': 'https://i.ibb.co/P4pSgS1/img2.jpg'},
        {'id': 5, 'name': 'Lasagna', 'category': 'Main Course', 'price': 14.99, 'image': 'https://i.ibb.co/Ldfwcqr0/img3.jpg'},
    ],
    'PISTA HOUSE': [
        {'id': 3, 'name': 'Pasta', 'category': 'Main Course', 'price': 10.99, 'image': 'https://i.ibb.co/4RpNVCWq/img4.jpg'},
        {'id': 4, 'name': 'Salad', 'category': 'Appetizers', 'price': 7.99, 'image': 'https://i.ibb.co/mPddWVF/img5.jpg'},
        {'id': 6, 'name': 'Soup', 'category': 'Appetizers', 'price': 6.49, 'image': 'https://i.ibb.co/6R6X1mRS/img6.jpg'},
    ],
    'SHOYU RESTAURANT': [
        {'id': 7, 'name': 'Sushi', 'category': 'Main Course', 'price': 15.99, 'image': 'https://i.ibb.co/jvLG5Lpb/img7.jpg'},
        {'id': 8, 'name': 'Tempura', 'category': 'Appetizers', 'price': 9.99, 'image': 'https://i.ibb.co/ksNmmLQk/img8.jpg'},
        {'id': 9, 'name': 'Ramen', 'category': 'Main Course', 'price': 12.99, 'image': 'https://i.ibb.co/9kMPvRjZ/img9.jpg'},
    ],
    'CREAM STONE': [
        {'id': 10, 'name': 'Chocolate', 'category': 'Main Course', 'price': 115, 'image': 'https://i.ibb.co/21WvGnt1/im.jpg'},
        {'id': 11, 'name': 'Butter scotch', 'category': 'Main Course', 'price': 99, 'image': 'https://i.ibb.co/20HtfK5V/im-1.jpg'},
        {'id': 12, 'name': 'Black currant', 'category': 'Main Course', 'price': 100, 'image': 'https://i.ibb.co/SDXjrSfm/im-2.jpg'},
    ],
    'KFC': [
        {'id': 10, 'name': 'Steak', 'category': 'Main Course', 'price': 18.99, 'image': 'https://i.ibb.co/ym1JTYfK/img10.jpg'},
        {'id': 11, 'name': 'Fries', 'category': 'Side', 'price': 4.99, 'image': 'https://i.ibb.co/60hGg93G/img11.jpg'},
        {'id': 12, 'name': 'Gravy', 'category': 'Side', 'price': 2.99, 'image': 'https://i.ibb.co/wF9LHs6m/img12.jpg'},
    ]
}


# Mock Users
users = {'user1': {'password': 'password1', 'name': 'John Doe', 'email': 'user1@example.com'}}

# Helper function to add items to the cart
def add_to_cart(item_id, restaurant_name):
    item = next((item for item in restaurants[restaurant_name] if item['id'] == item_id), None)
    if item:
        # Initialize cart if it doesn't exist
        if 'cart' not in session:
            session['cart'] = []
        
        # Check if item is already in cart
        existing_item = next((i for i in session['cart'] if i['id'] == item['id']), None)
        if existing_item:
            existing_item['quantity'] += 1  # Increment quantity
        else:
            item_copy = item.copy()  # Make a copy of the item to avoid modifying the original
            item_copy['quantity'] = 1  # Start with 1 quantity
            session['cart'].append(item_copy)

    session.modified = True

@app.route('/')
def home():
    return render_template('home.html', restaurants=restaurants)

@app.route('/add_to_cart/<restaurant_name>/<int:item_id>')
def add_item_to_cart(restaurant_name, item_id):
    add_to_cart(item_id, restaurant_name)
    return redirect(url_for('home'))

@app.route('/cart')
def cart():
    if 'user' not in session:  # Check if user is logged in
        flash('You must be logged in to view the cart!')
        return redirect(url_for('login'))  # Redirect to login page if not logged in

    cart_items = session.get('cart', [])
    total_price = sum(item['price'] * item['quantity'] for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total_price=total_price)

@app.route('/remove_from_cart/<int:item_id>')
def remove_from_cart(item_id):
    cart_items = session.get('cart', [])
    cart_items = [item for item in cart_items if item['id'] != item_id]
    session['cart'] = cart_items
    session.modified = True
    return redirect(url_for('cart'))

@app.route('/order_history')
def order_history():
    orders = session.get('orders', [])
    return render_template('order_history.html', orders=orders)

@app.route('/order_tracking/<int:order_id>')
def order_tracking(order_id):
    orders = session.get('orders', [])
    # Ensure the order_id exists in session
    order = next((order for order in orders if order['order_id'] == order_id), None)
    
    if order is None:
        flash("Order not found!")
        return redirect(url_for('order_history'))

    return render_template('order_tracking.html', order=order)

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if 'user' not in session:  # Check if user is logged in
        flash('You must be logged in to checkout!')
        return redirect(url_for('login'))  # Redirect to login if not logged in
    
    cart_items = session.get('cart', [])
    if not cart_items:  # Check if the cart is empty
        flash('Your cart is empty!')
        return redirect(url_for('cart'))  # Redirect to the cart page if empty

    if request.method == 'POST':
        # Mock Order ID and Payment Process (for simplicity)
        order_id = random.randint(1000, 9999)
        order_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        order = {
            'order_id': order_id,
            'items': cart_items,
            'total': sum(item['price'] * item['quantity'] for item in cart_items),
            'status': 'Processing',
            'order_time': order_time
        }

        # Add order to session (as mock order history)
        if 'orders' not in session:
            session['orders'] = []
        session['orders'].append(order)
        session['cart'] = []  # Clear the cart after checkout
        session.modified = True

        flash('Order placed successfully!')

        # Redirect with a short delay to the home page
        return render_template('order_success.html', order=order)

    # If it's a GET request, display the checkout page
    total_price = sum(item['price'] * item['quantity'] for item in cart_items)
    return render_template('checkout.html', cart_items=cart_items, total_price=total_price)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = users.get(username)
        if user and user['password'] == password:
            session['user'] = username
            flash('Logged in successfully!')
            next_page = request.args.get('next')  # Get the next page parameter
            return redirect(next_page or url_for('home'))  # Redirect to next page or home if not specified
        flash('Invalid credentials!')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('Logged out successfully!')
    return redirect(url_for('home'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        name = request.form['name']
        
        # Simple validation (no duplicates)
        if username in users:
            flash('Username already exists!')
        else:
            users[username] = {'password': password, 'name': name, 'email': email}
            flash('Registration successful! Please log in.')

        return redirect(url_for('login'))

    return render_template('register.html')

if __name__ == '__main__':
    app.run(debug=True)