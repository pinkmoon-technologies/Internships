from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from forms import LoginForm, RegisterForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Sample in-memory data (users, products, and cart)
users = {}
products = [
    {"id": 1, "name": "E-Book: Learn Python", "description": "A comprehensive guide to Python programming.", "price": 19.99, "file_path": "path/to/python_ebook.pdf"},
    {"id": 2, "name": "Software: Web Scraper", "description": "Automate your data scraping tasks.", "price": 49.99, "file_path": "path/to/web_scraper.zip"},
    {"id": 3, "name": "Digital Art: Abstract Painting", "description": "A beautiful piece of abstract digital artwork.", "price": 99.99, "file_path": "path/to/abstract_painting.png"},
    {"id": 4, "name": "Course: Web Development Bootcamp", "description": "Learn HTML, CSS, JavaScript, and more!", "price": 199.99, "file_path": "path/to/web_dev_course.jpg"},
    {"id": 5, "name": "Course: Data Science 101", "description": "Beginner guide to data science with Python.", "price": 149.99, "file_path": "path/to/data_science_course.jpg"},
    {"id": 6, "name": "Course: Machine Learning Mastery", "description": "Dive into the world of AI and machine learning.", "price": 249.99, "file_path": "path/to/ml_course.jpg"},
    {"id": 7, "name": "Course: Digital Marketing Fundamentals", "description": "Learn the basics of digital marketing.", "price": 99.99, "file_path": "path/to/digital_marketing_course.jpg"}
]


cart_items = {}

# User model
class User(UserMixin):
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password

@login_manager.user_loader
def load_user(user_id):
    return users.get(user_id)

# Routes
@app.route('/')
def home():
    # Get the number of items in the cart
    cart_count = len(session.get('cart', []))
    
    products = [
        {"id": 1, "name": "E-Book: Learn Python", "description": "A comprehensive guide to Python programming.", "price": 19.99, "file_path": "https://m.media-amazon.com/images/I/51Rvz7T68ML._SX342_SY445_.jpg"},
        {"id": 2, "name": "Software: Web Scraper", "description": "Automate your data scraping tasks.", "price": 49.99, "file_path": "https://m.media-amazon.com/images/I/41yRwJgNbCL._SY445_SX342_.jpg"},
        {"id": 3, "name": "Digital Art: Abstract Painting", "description": "A beautiful piece of abstract digital artwork.", "price": 99.99, "file_path": "https://m.media-amazon.com/images/I/81Oo2KSj1UL._SY425_.jpg"},
        {"id": 4, "name": "Course: Web Development Bootcamp", "description": "Learn HTML, CSS, JavaScript, and more!", "price": 199.99, "file_path": "https://m.media-amazon.com/images/I/41Z1QWzYmML._SY445_SX342_.jpg"},
        {"id": 5, "name": "Course: Data Science 101", "description": "Beginner guide to data science with Python.", "price": 149.99, "file_path": "https://m.media-amazon.com/images/I/41W-pOyvTeL._SY445_SX342_.jpg"},
        
        {"id": 6, "name": "Course: Machine Learning Mastery", "description": "Dive into the world of AI and machine learning.", "price": 249.99, "file_path": "https://m.media-amazon.com/images/I/41J1mIHCo4L._SY445_SX342_.jpg"},
        {"id": 7, "name": "Course: Digital Marketing Fundamentals", "description": "Learn the basics of digital marketing.", "price": 99.99, "file_path": "https://m.media-amazon.com/images/I/51-004rS8AL._SY445_SX342_.jpg"},
        {"id": 8, "name": "E-Book: The Art of Web Design", "description": "A deep dive into web design and UX principles.", "price": 29.99, "file_path": "https://m.media-amazon.com/images/I/817J2NQiCWL._SY425_.jpg"},
        {"id": 9, "name": "Software: Photo Editor Pro", "description": "Advanced photo editing software with powerful features.", "price": 59.99, "file_path": "https://m.media-amazon.com/images/I/51Vuw4RHHRL._SY445_SX342_.jpg"},
        {"id": 10, "name": "Digital Art: Landscape Art", "description": "A serene digital landscape painting for your collection.", "price": 79.99, "file_path": "https://m.media-amazon.com/images/I/51GDRjWU8VL._SX342_SY445_.jpg"}
    ]
    
    return render_template('home.html', products=products, cart_count=cart_count)



@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = next((prod for prod in products if prod["id"] == product_id), None)
    return render_template('product_detail.html', product=product)

@app.route('/cart')
@login_required
def cart():
    # Get the cart from the session
    cart = session.get('cart', [])
    
    # Calculate the total price
    total_price = sum(item['price'] for item in cart)
    
    return render_template('cart.html', total_price=total_price)



@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
@login_required  # Ensures that only logged-in users can add to cart
def add_to_cart(product_id):
    # Get the product by ID (from session or database)
    product = next((item for item in products if item['id'] == product_id), None)
    
    if product:
        # Retrieve the cart from the session or create an empty one
        cart = session.get('cart', [])
        
        # Add the product to the cart
        cart.append(product)
        session['cart'] = cart  # Update the cart in session
    
    return redirect(url_for('home'))  # Redirect back to the homepage after adding



@app.route('/remove_from_cart/<int:product_id>', methods=['POST'])
@login_required
def remove_from_cart(product_id):
    # Get the current cart from session
    cart = session.get('cart', [])
    
    # Filter out the product from the cart
    cart = [item for item in cart if item['id'] != product_id]
    
    # Update the session cart
    session['cart'] = cart
    
    # Flash a message to notify the user
    flash('Product removed from your cart!')
    
    return redirect(url_for('cart'))  # Redirect back to the cart page


@app.route('/checkout')
@login_required
def checkout():
    user_cart = cart_items.get(current_user.id, [])
    total_price = sum(product['price'] for product in user_cart)
    return render_template('order_summary.html', cart_items=user_cart, total_price=total_price)

@app.route('/order', methods=['POST'])
@login_required
def order():
    cart_items[current_user.id] = []  # Empty the cart after order is placed
    flash('Your order has been placed successfully!', 'success')
    return redirect(url_for('home'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = users.get(form.username.data)
        if user and check_password_hash(user.password, form.password.data):
            login_user(user)
            flash('Logged in successfully!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Login failed. Check your username and password.', 'danger')
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        username = form.username.data
        if username in users:
            flash('Username already taken. Please choose another one.', 'danger')
        else:
            password_hash = generate_password_hash(form.password.data)
            new_user = User(id=username, username=username, password=password_hash)
            users[username] = new_user
            login_user(new_user)
            flash('Registration successful!', 'success')
            return redirect(url_for('home'))
    return render_template('register.html', form=form)

@app.route('/process_payment', methods=['POST'])
@login_required
def process_payment():
    # Here you can process the payment (you may use a payment gateway API in the future)
    # For now, we simulate the payment process by just flashing a message and clearing the cart.

    # Clear the cart
    session.pop('cart', None)
    
    # Flash a success message for order placement
    flash('Order placed successfully!')
    
    # Redirect to home after 3 seconds (handled by JavaScript in the template)
    return redirect(url_for('home'))



if __name__ == '__main__':
    app.run(debug=True)
