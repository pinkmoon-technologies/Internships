from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Simulated list of donation causes with initial funds raised.
causes = [
    {"id": 1, "name": "Feed the Hungry", "description": "Help provide food for the homeless.", "funds": 1000, "image": "image1.jpg"},
    {"id": 2, "name": "Clean Water Initiative", "description": "Donate to provide clean water in developing areas.", "funds": 500, "image": "image2.jpg"},
    {"id": 3, "name": "Education for All", "description": "Support education programs for underprivileged children.", "funds": 300, "image": "image3.jpg"},
    {"id": 4, "name": "Save the Environment", "description": "Support environmental conservation efforts.", "funds": 800, "image": "image4.jpg"},
    {"id": 5, "name": "Health and Wellness", "description": "Help provide medical assistance to the needy.", "funds": 650, "image": "image5.jpeg"},
    {"id": 6, "name": "Support Students", "description": "Help provide scholarships and study resources for students.", "funds": 1200, "image": "image6.jpg"},
]

@app.route('/')
def index():
    total_funds = sum(cause['funds'] for cause in causes)  # Total funds raised across all causes
    return render_template('index.html', causes=causes, total_funds=total_funds)

@app.route('/donate/<int:cause_id>', methods=['GET', 'POST'])
def donate(cause_id):
    if request.method == 'POST':
        amount = float(request.form['amount'])
        email = request.form['email']
        cause = next(cause for cause in causes if cause['id'] == cause_id)
        cause['funds'] += amount  # Add the donation to the cause's funds
        return redirect(url_for('index', success=True))  # Redirect to home with success message

    cause = next(cause for cause in causes if cause['id'] == cause_id)
    return render_template('donate.html', cause=cause)

if __name__ == '__main__':
    app.run(debug=True)
