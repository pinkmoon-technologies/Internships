from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Necessary for sessions

# Simulated list of donation causes with initial funds raised
causes = [
    {"id": 1, "name": "Feed the Hungry", "description": "Feeding the hungry is better than raising the dead.", "funds": 1000, "image": "https://files.globalgiving.org/pfil/14810/ph_14810_164205.jpg?m=1570734348000"},
    {"id": 2, "name": "Clean Water Initiative", "description": "Donate to provide clean water in developing areas.", "funds": 500,"image": "https://cleanwater.org/sites/default/files/CW_March_IMG_1457a3cQ-1.jpg"},
    {"id": 3, "name": "Education for All", "description": "Support education programs for underprivileged children.", "funds": 300, "image": "https://files.globalgiving.org/pfil/25997/pict_featured_jumbo.jpg?t=1480395600000"},
    {"id": 4, "name": "Save the Environment", "description": "Support environmental conservation efforts.", "funds": 800, "image": "https://wpassets.adda247.com/wp-content/uploads/multisite/sites/5/2022/09/27075244/world-environment.png"},
    {"id": 5, "name": "Health and Wellness", "description": "Help provide medical assistance to the needy.", "funds": 650, "image": "https://aathmafoundation.org/wp-content/uploads/2022/08/3-scaled.jpg"},
    {"id": 6, "name": "Support Students", "description": "Help provide scholarships and study resources for students.", "funds": 1200, "image": "https://discoverblog.s3.ap-south-1.amazonaws.com/discover/wp-content/uploads/2023/06/09121525/Best-Scholarships-for-Indian-Students-Merit-Scholarship.png"},
  
]

# Admin credentials (for simplicity, use hardcoded credentials)
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'password'

@app.route('/')
def index():
    total_funds = sum(cause['funds'] for cause in causes)  # Total funds raised across all causes
    return render_template('index.html', causes=causes, total_funds=total_funds, is_admin=session.get('is_admin', False))

@app.route('/donate/<int:cause_id>', methods=['GET', 'POST'])
def donate(cause_id):
    if request.method == 'POST':
        amount = float(request.form['amount'])
        email = request.form['email']
        cause = next(cause for cause in causes if cause['id'] == cause_id)
        cause['funds'] += amount  # Add the donation to the cause's funds
        return redirect(url_for('index', success=True))  # Redirect to home with success message

    cause = next(cause for cause in causes if cause['id'] == cause_id)
    return render_template('donate.html', cause=cause)

@app.route('/admin/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username == "admin" and password == "password":
            session['is_admin'] = True  # Set the session flag to indicate admin is logged in
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error="Invalid credentials")

    return render_template('login.html')

@app.route('/admin/withdraw', methods=['POST'])
def withdraw():
    if session.get('is_admin', False):  # Check if user is admin
        total_funds = sum(cause['funds'] for cause in causes)  # Get the total donations
        # Simulate withdrawing funds (in this case, just reset to 0)
        for cause in causes:
            cause['funds'] = 0
        return redirect(url_for('index', success_withdraw=True, total_funds=total_funds))
    return redirect(url_for('login'))  # Redirect to login if not an admin

@app.route('/admin/logout')
def logout():
    session.pop('is_admin', None)  # Remove admin flag from session
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
