from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Required for sessions

# Updated mock data with at least 6 products per category
# Mock data with six e-commerce platforms
mock_data = {
    'Laptop': [
        {'platform': 'Amazon', 'price': 899.99, 'rating': 4.5, 'features': ['Intel i7', '16GB RAM', '512GB SSD', '15.6" Display']},
        {'platform': 'eBay', 'price': 850.00, 'rating': 4.4, 'features': ['Intel i7', '8GB RAM', '512GB SSD', '14" Display']},
        {'platform': 'BestBuy', 'price': 950.00, 'rating': 4.6, 'features': ['Intel i7', '16GB RAM', '1TB SSD', '15.6" Display']},
        {'platform': 'Walmart', 'price': 920.00, 'rating': 4.5, 'features': ['Intel i5', '16GB RAM', '512GB SSD', '15.6" Display']},
        {'platform': 'Flipkart', 'price': 880.00, 'rating': 4.3, 'features': ['AMD Ryzen 7', '16GB RAM', '1TB SSD', '14" Display']},
        {'platform': 'AliExpress', 'price': 870.00, 'rating': 4.2, 'features': ['Intel i5', '8GB RAM', '512GB SSD', '15.6" Display']}
    ],
    'Phone': [
        {'platform': 'Amazon', 'price': 699.99, 'rating': 4.7, 'features': ['6.1" Display', '128GB Storage', '12MP Camera', 'A14 Bionic Chip']},
        {'platform': 'eBay', 'price': 680.00, 'rating': 4.5, 'features': ['6.1" Display', '64GB Storage', '12MP Camera', 'A14 Bionic Chip']},
        {'platform': 'BestBuy', 'price': 720.00, 'rating': 4.8, 'features': ['6.1" Display', '128GB Storage', '12MP Camera', 'A14 Bionic Chip']},
        {'platform': 'AliExpress', 'price': 650.00, 'rating': 4.2, 'features': ['6.5" Display', '256GB Storage', '16MP Camera', 'Snapdragon 888']},
        {'platform': 'Target', 'price': 710.00, 'rating': 4.6, 'features': ['6.2" Display', '128GB Storage', '12MP Camera', 'A15 Bionic Chip']},
        {'platform': 'Walmart', 'price': 690.00, 'rating': 4.4, 'features': ['6.4" Display', '128GB Storage', '12MP Camera', 'Snapdragon 870']}
    ],
    'Watch': [
        {'platform': 'Amazon', 'price': 150.99, 'rating': 4.7, 'features': ['1.3" Display', 'GPS', 'Heart Rate Monitor', 'Water Resistant']},
        {'platform': 'eBay', 'price': 170.00, 'rating': 4.5, 'features': ['1.3" Display', 'GPS', 'Heart Rate Monitor', 'Stainless Steel Frame']},
        {'platform': 'Flipkart', 'price': 140.00, 'rating': 4.8, 'features': ['1.4" Display', 'GPS', 'Blood Oxygen Sensor', 'Wireless Charging']},
        {'platform': 'BestBuy', 'price': 160.00, 'rating': 4.6, 'features': ['1.2" Display', 'GPS', 'ECG Sensor', 'Water Resistant']},
        {'platform': 'Target', 'price': 155.00, 'rating': 4.5, 'features': ['1.3" Display', 'GPS', 'Blood Pressure Monitor', 'Fitness Tracking']},
        {'platform': 'Walmart', 'price': 145.00, 'rating': 4.4, 'features': ['1.3" Display', 'GPS', 'Sleep Monitoring', 'Bluetooth Call Support']}
    ],
    'Tv': [
        {'platform': 'Amazon', 'price': 300.99, 'rating': 4.5, 'features': ['103 cm" Display', '2GB Storage', 'HDMI PORTS:2|2 USB Ports', 'Android OS']},
        {'platform': 'eBay', 'price': 320.00, 'rating': 4.3, 'features': ['103" Display', 'HDMI PORTS:2|2 USB Ports', 'Android OS']},
        {'platform': 'BestBuy', 'price': 310.00, 'rating': 4.7, 'features': ['103" Display', 'HDMI PORTS:2|2 USB Ports', 'Android OS']},
        {'platform': 'Flipkart', 'price': 290.00, 'rating': 4.6, 'features': ['103" Display', '3 HDMI Ports', 'Smart TV']},
        {'platform': 'Target', 'price': 315.00, 'rating': 4.4, 'features': ['103" Display', '4 HDMI Ports', 'OLED Panel']},
        {'platform': 'Walmart', 'price': 305.00, 'rating': 4.3, 'features': ['103" Display', '2 HDMI Ports', 'Google Assistant Built-in']}
    ],
    'Tabs': [
        {'platform': 'Amazon', 'price': 200.99, 'rating': 4.7, 'features': ['14.1" Display', '128GB Storage', '12MP Camera', 'A14 Bionic Chip']},
        {'platform': 'eBay', 'price': 250.00, 'rating': 4.5, 'features': ['14.1" Display', '64GB Storage', '12MP Camera', 'A14 Bionic Chip']},
        {'platform': 'BestBuy', 'price': 225.00, 'rating': 4.8, 'features': ['14.1" Display', '128GB Storage', '12MP Camera', 'A14 Bionic Chip']},
        {'platform': 'Flipkart', 'price': 215.00, 'rating': 4.6, 'features': ['14.1" Display', '256GB Storage', 'Snapdragon Processor']},
        {'platform': 'Target', 'price': 230.00, 'rating': 4.4, 'features': ['14.1" Display', '128GB Storage', 'MediaTek Processor']},
        {'platform': 'Walmart', 'price': 210.00, 'rating': 4.3, 'features': ['14.1" Display', '64GB Storage', 'Apple M1 Chip']}
    ],
    'Headphones': [
        {'platform': 'Amazon', 'price': 199.99, 'rating': 4.4, 'features': ['Noise Cancelling', '20 Hours Battery', 'Bluetooth 5.0']},
        {'platform': 'eBay', 'price': 180.00, 'rating': 4.3, 'features': ['Noise Cancelling', '15 Hours Battery', 'Bluetooth 4.2']},
        {'platform': 'BestBuy', 'price': 220.00, 'rating': 4.6, 'features': ['Noise Cancelling', '30 Hours Battery', 'Bluetooth 5.0']},
        {'platform': 'Flipkart', 'price': 190.00, 'rating': 4.5, 'features': ['Noise Cancelling', '25 Hours Battery', 'Wireless Charging']},
        {'platform': 'Target', 'price': 210.00, 'rating': 4.4, 'features': ['Noise Cancelling', '22 Hours Battery', 'Adaptive Sound']},
        {'platform': 'Walmart', 'price': 185.00, 'rating': 4.3, 'features': ['Noise Cancelling', '18 Hours Battery', 'Sweat Resistant']}
    ]
}

# Mock user authentication
users = {'student1': 'password1'}

@app.route('/')
def index():
    return render_template('index.html', categories=list(mock_data.keys()))

@app.route('/compare', methods=['POST'])
def compare():
    if 'user' not in session:
        return redirect(url_for('login'))

    product_name = request.form['product_name']
    product_category = request.form['category']

    if product_category not in mock_data:
        return render_template('index.html', categories=list(mock_data.keys()), error="Invalid category selected.")
    
    return render_template('comparison_result.html', product_name=product_name, product_comparison=mock_data[product_category])

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if users.get(username) == password:
            session['user'] = username
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error="Invalid credentials.")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users:
            return render_template('register.html', error="Username already exists.")
        users[username] = password
        return redirect(url_for('login'))
    return render_template('register.html')

if __name__ == '__main__':
    app.run(debug=True)
