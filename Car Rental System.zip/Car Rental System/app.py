from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Required for flash messages

# List of cars available for rent
cars = [
    {"id": 1, "model": "Toyota Corolla", "price_per_day": 950, "image": "https://i.ibb.co/JMM5tTB/im-1.jpg"},
    {"id": 2, "model": "Honda Civic", "price_per_day": 860, "image": "https://i.ibb.co/0RLsSYzS/im-2.jpg"},
    {"id": 3, "model": "Ford Mustang", "price_per_day": 1500, "image": "https://i.ibb.co/W4cWCzc7/im-3.jpg"},
    {"id": 4, "model": "Chevrolet Malibu", "price_per_day": 1750, "image": "https://i.ibb.co/08Wkz90/im-4.jpg"},
    {"id": 5, "model": "BMW 3 Series", "price_per_day": 1000, "image": "https://i.ibb.co/d4HN7Q8q/im-5.jpg"},
    {"id": 6, "model": "Audi A4", "price_per_day": 1300, "image": "https://i.ibb.co/yF2MfHXJ/im-6.jpg"},
    {"id": 7, "model": "Mercedes-Benz C-Class", "price_per_day": 1500, "image": "https://i.ibb.co/Ld8CT9SJ/im-7.jpg"},
    {"id": 8, "model": "Porsche 911", "price_per_day": 2000, "image": "https://i.ibb.co/qFkyQpxk/im-8.jpg"},
    {"id": 9, "model": "Alto", "price_per_day": 500, "image": "https://i.ibb.co/G45TfcDc/im-9.jpg"},
    {"id": 10, "model": "Brezza", "price_per_day": 900, "image": "https://i.ibb.co/hJy0yn2N/im-10.jpg"},
    {"id": 11, "model": "Nano", "price_per_day": 600, "image": "https://i.ibb.co/RGn4k4mm/im-11.jpg"},
    {"id": 12, "model": "Punch", "price_per_day": 800, "image": "https://i.ibb.co/YT3RBc7r/im-12.jpg"}
]

# Mock database for reservations (for simplicity)
reservations = []  # List of rented cars
available_cars = cars[:]  # List of cars available for rent

@app.route('/')
def home():
    return render_template('index.html', cars=available_cars, rented_cars=reservations)

@app.route('/rental_details/<int:car_id>', methods=['GET', 'POST'])
def rental_details(car_id):
    car = next((car for car in available_cars if car["id"] == car_id), None)
    if request.method == 'POST':
        # Retrieve selected rental dates, username, and address
        start_date_str = request.form['start_date']
        end_date_str = request.form['end_date']
        username = request.form['username']
        address = request.form['address']
        
        try:
            start_date = datetime.strptime(start_date_str, "%Y-%m-%d")
            end_date = datetime.strptime(end_date_str, "%Y-%m-%d")
            
            # Validate that the start date is earlier than the end date
            if start_date >= end_date:
                flash("Start date must be earlier than end date!", "error")
                return redirect(url_for('rental_details', car_id=car_id))
            
            # Calculate total days and price
            total_days = (end_date - start_date).days
            if total_days <= 0:
                flash("Rental period must be at least 1 day!", "error")
                return redirect(url_for('rental_details', car_id=car_id))
            
            total_price = total_days * car["price_per_day"]
            
            # Move car from available to rented
            available_cars.remove(car)
            reservation = {
                "car": car["model"],
                "username": username,
                "address": address,
                "start_date": start_date_str,
                "end_date": end_date_str,
                "total_price": total_price,
                "image": car["image"]
            }
            reservations.append(reservation)
            return redirect(url_for('success', car_model=car["model"], total_price=total_price))
        
        except ValueError:
            flash("Invalid date format. Please enter valid dates.", "error")
            return redirect(url_for('rental_details', car_id=car_id))

    return render_template('rental_details.html', car=car)

@app.route('/cancel_rental/<int:reservation_index>')
def cancel_rental(reservation_index):
    # Move car back to available cars
    reservation = reservations.pop(reservation_index)
    car = {
        "id": len(available_cars) + 1,  # Assign a new ID (or keep the same one)
        "model": reservation["car"],
        "price_per_day": 50,  # Reset the price per day (you can adjust this as needed)
        "image": reservation["image"]
    }
    available_cars.append(car)
    flash(f"Rental for {reservation['car']} has been cancelled successfully.", "success")
    return redirect(url_for('home'))

@app.route('/success')
def success():
    car_model = request.args.get('car_model')
    total_price = request.args.get('total_price')
    return render_template('success.html', car_model=car_model, total_price=total_price)

if __name__ == '__main__':
    app.run(debug=True)
