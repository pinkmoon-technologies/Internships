from flask import Flask, render_template, request, redirect, url_for, session, flash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Fake users data (username, password, role)
users = {
    "student1": {"password": "password123", "role": "student"},
    "teacher1": {"password": "password456", "role": "teacher"}
}

# Fake classes data
classes = [
    {"id": 1, "name": "Mathematics", "schedule": "Monday 10 AM"},
    {"id": 2, "name": "Physics", "schedule": "Tuesday 11 AM"},
    {"id": 3, "name": "Chemistry", "schedule": "Wednesday 9 AM"}
]

# Fake quizzes data
quizzes = {
    1: [{"question": "What is 2 + 2?", "options": ["2", "4", "6"], "answer": "4"}],
    2: [{"question": "What is the unit of force in SI?", "options": ["joule", "newton", "watt"], "answer": "newton"}],
    3: [{"question": "What is the chemical symbol for water?", "options": ["H2O", "CO2", "O2"], "answer": "H2O"}]
}

# Fake results data (for scoreboard)
results = {}

# ---------------------- AUTHENTICATION ----------------------
@app.route('/')
def index():
    return render_template('index.html', classes=classes)

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = users.get(username)
        
        if user and user['password'] == password:
            session['user'] = username
            session['role'] = user['role']  # Store the user role
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error="Invalid credentials")
    
    return render_template('login.html')

@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        if username in users:
            return render_template('register.html', error="Username already taken.")
        
        users[username] = {'password': password, 'role': role}
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    session.pop('role', None)
    return redirect(url_for('index'))

# ---------------------- DASHBOARD ----------------------
@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    role = session.get('role')
    
    if role == "teacher":
        return render_template('dashboard_teacher.html', classes=classes)
    else:
        return render_template('dashboard_student.html', classes=classes, results=results)

@app.route('/classroom/<int:id>')
def classroom(id):
    if 'user' not in session:
        return redirect(url_for('login'))
    
    class_ = next((cls for cls in classes if cls["id"] == id), None)
    return render_template('classroom.html', class_=class_)

# ---------------------- QUIZ CREATION (TEACHERS ONLY) ----------------------
@app.route('/create_quiz/<int:id>', methods=['GET', 'POST'])
def create_quiz(id):
    if 'user' not in session or session.get('role') != "teacher":
        flash("Access Denied! Only teachers can create quizzes.", "danger")
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        question = request.form['question']
        options = [request.form['option1'], request.form['option2'], request.form['option3']]
        answer = request.form['answer']
        
        if id not in quizzes:
            quizzes[id] = []
        
        quizzes[id].append({'question': question, 'options': options, 'answer': answer})
        
        flash("Quiz question added successfully!", "success")
        return redirect(url_for('dashboard'))
    
    return render_template('create_quiz.html', class_id=id)

# ---------------------- QUIZ TAKING (STUDENTS ONLY) ----------------------
@app.route('/quiz/<int:id>', methods=['GET', 'POST'])
def quiz(id):
    if 'user' not in session:
        return redirect(url_for('login'))

    role = session.get('role')
    if role == "teacher":
        return redirect(url_for('dashboard'))  # Prevent teachers from taking the quiz

    quiz_data = quizzes.get(id, [])

    if request.method == 'POST':
        score = 0
        total_questions = len(quiz_data)
        feedback = []

        for i, question in enumerate(quiz_data):
            user_answer = request.form.get(f"question_{i + 1}")

            if user_answer == question['answer']:
                score += 1
                feedback.append((question['question'], "Correct", user_answer))
            else:
                feedback.append((question['question'], "Wrong", user_answer))

        # Save the score in the results dictionary
        results[session['user']] = {"score": score, "total": total_questions}

        return render_template('scoreboard.html', score_info={"score": score, "total": total_questions}, feedback=feedback)

    return render_template('quiz.html', quiz_data=quiz_data)

# ---------------------- SCOREBOARD ----------------------
@app.route('/scoreboard')
def scoreboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    score_info = results.get(session['user'], {"score": 0, "total": 0})
    return render_template('scoreboard.html', score_info=score_info)

# ---------------------- FEEDBACK ----------------------
@app.route('/feedback/<int:id>', methods=['GET', 'POST'])
def feedback(id):
    if 'user' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        feedback_text = request.form['feedback']
        flash("Thank you for your feedback!", "success")
        return redirect(url_for('dashboard'))
    
    return render_template('feedback.html')

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
