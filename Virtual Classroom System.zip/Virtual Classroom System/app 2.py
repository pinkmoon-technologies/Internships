from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Fake users data (username, password, role)
users = {
    "student1": {"password": "password123", "role": "student"},
    "teacher1": {"password": "password456", "role": "teacher"}
}

# Fake classes data
classes = [
    {"id": 1, "name": "Mathematics", "schedule": "Monday 10 AM"},
    {"id": 2, "name": "Physics", "schedule": "Tuesday 11 AM"},
    {"id": 3, "name": "Chemistry", "schedule": "Wednesday 9 AM"}
]

# Fake quizzes data
quizzes = {
    1: [{"question": "What is 2 + 2?", "options": ["2", "4", "6"], "answer": "4"}],
    2: [{"question": "What is the unit of force in the International System of Units (SI)?", "options": ["joule", "newton", "watt"], "answer": "newton"}],
    3: [{"question": "What is the chemical symbol for water?", "options": ["H2O", "CO2", "O2"], "answer": "H2O"}]
}

# Fake results data (for scoreboard)
results = {}

@app.route('/')
def index():
    return render_template('index.html', classes=classes)

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = users.get(username)
        
        if user and user['password'] == password:
            session['user'] = username
            session['role'] = user['role']  # Store the user role
            next_page = request.args.get('next', url_for('dashboard'))  # Redirect to the intended page
            return redirect(next_page)
        else:
            return render_template('login.html', error="Invalid credentials")
    
    return render_template('login.html')

@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        # Check if the username already exists
        if username in users:
            return render_template('register.html', error="Username already taken.")
        
        # Save the user in the "database" (users dictionary)
        users[username] = {'password': password, 'role': role}

        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    role = session.get('role')
    
    if role == "teacher":
        return render_template('dashboard_teacher.html', classes=classes)
    else:
        return render_template('dashboard_student.html', classes=classes, results=results)

@app.route('/classroom/<int:id>')
def classroom(id):
    if 'user' not in session:  # Check if the user is logged in
        return redirect(url_for('login'))  # Redirect to login if not logged in
    
    class_ = next((cls for cls in classes if cls["id"] == id), None)
    return render_template('classroom.html', class_=class_)

@app.route('/create_quiz/<int:id>', methods=['GET', 'POST'])
def create_quiz(id):
    if 'user' not in session:
        return redirect(url_for('login'))  # Redirect to login if not logged in
    
    if request.method == 'POST':
        # Get the quiz data from the form (question, options, answer)
        question = request.form['question']
        options = [request.form['option1'], request.form['option2'], request.form['option3']]
        answer = request.form['answer']
        
        # Save the quiz question in the quizzes dictionary (or database)
        if id not in quizzes:
            quizzes[id] = []
        
        quizzes[id].append({
            'question': question,
            'options': options,
            'answer': answer
        })
        
        # Redirect back to the teacher's dashboard after saving the quiz question
        return redirect(url_for('dashboard'))
    
    return render_template('create_quiz.html', class_id=id)

@app.route('/quiz/<int:id>', methods=['GET', 'POST'])
def quiz(id):
    if 'user' not in session:
        return redirect(url_for('login'))  # Redirect to login if not logged in
    
    quiz_data = quizzes.get(id, [])
    
    if request.method == 'POST':
        score = 0
        total_questions = len(quiz_data)
        feedback = []

        # Loop through each question to check answers
        for i, question in enumerate(quiz_data):
            user_answer = request.form.get(f"question_{i + 1}")  # Get the selected answer
            
            # Check if the selected answer is correct
            if user_answer == question['answer']:
                score += 1
                feedback.append((question['question'], "Correct", user_answer))
            else:
                feedback.append((question['question'], "Wrong", user_answer))

        # Save the score to the results (can be stored in a database)
        results[session['user']] = {"score": score, "total": total_questions}

        # Redirect to the score page with feedback
        return render_template('scoreboard.html', score_info={"score": score, "total": total_questions}, feedback=feedback)
    
    return render_template('quiz.html', quiz_data=quiz_data)

@app.route('/scoreboard')
def scoreboard():
    # Display the results for the user
    if 'user' not in session:
        return redirect(url_for('login'))
    score_info = results.get(session['user'], {"score": 0, "total": 0})
    return render_template('scoreboard.html', score_info=score_info)

@app.route('/feedback/<int:id>', methods=['GET', 'POST'])
def feedback(id):
    if 'user' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        feedback_text = request.form['feedback']
        # Store feedback here if needed
        return redirect(url_for('dashboard'))
    
    return render_template('feedback.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    session.pop('role', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)