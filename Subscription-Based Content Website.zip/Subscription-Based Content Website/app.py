from flask import Flask, render_template, redirect, url_for, request, flash, session
import json

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Load users and content from JSON (In real-world, use a database)
def load_users():
    with open('data/users.json') as f:
        return json.load(f)

def load_content():
    with open('data/content.json') as f:
        return json.load(f)

# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users = load_users()
        user_id = len(users) + 1  # Simple user ID generation
        new_user = {'id': user_id, 'username': username, 'password': password, 'subscription': 'free'}
        users.append(new_user)
        
        # Save user to data file
        with open('data/users.json', 'w') as f:
            json.dump(users, f, indent=4)
        
        flash("Registration successful! Please log in.", "success")
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        users = load_users()
        user = next((u for u in users if u['username'] == username), None)
        
        if user and user['password'] == password:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['subscription'] = user['subscription']
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid credentials. Please try again.", "danger")
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    content = load_content()
    if session['subscription'] == 'free':
        content = [item for item in content if item['access'] == 'free']
    
    return render_template('dashboard.html', content=content)

@app.route('/content/<int:content_id>')
def content_page(content_id):
    content = load_content()
    content_item = next((item for item in content if item['id'] == content_id), None)
    
    if content_item is None:
        return redirect(url_for('index'))
    
    return render_template('content_page.html', content_item=content_item)

@app.route('/subscribe')
def subscribe():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    # Simulate the subscription process (e.g., integrate payment gateway)
    return render_template('payment_gateway.html')

@app.route('/payment-success')
def payment_success():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    # Simulate the process of upgrading to premium
    session['subscription'] = 'premium'

    # Update user subscription in data file
    users = load_users()
    for user in users:
        if user['id'] == session['user_id']:
            user['subscription'] = 'premium'
            break
    
    with open('data/users.json', 'w') as f:
        json.dump(users, f, indent=4)
    
    flash("You have successfully subscribed to the Premium plan!", "success")
    return redirect(url_for('dashboard'))

@app.route('/payment-cancelled')
def payment_cancelled():
    flash("Payment was cancelled. Please try again.", "danger")
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    app.run(debug=True)
