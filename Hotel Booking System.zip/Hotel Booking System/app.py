from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import datetime
from flask import session

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for flash messages

# Sample room data (in real application, this would be stored in a database)
rooms = [
    {"id": 1, "name": "Single Room", "price": 100, "available": True, "image": "hotel1.jpeg"},
    {"id": 2, "name": "Double Room", "price": 150, "available": True, "image": "hotel2.jpeg"},
    {"id": 3, "name": "Suite", "price": 250, "available": True, "image": "hotel3.jpeg"}
]


# In-memory "database" for users and bookings
users = {}
bookings = []

# Home route displaying available rooms
@app.route('/')
def index():
    return render_template('index.html', rooms=rooms)

# Route to handle booking a room
@app.route('/book/<int:room_id>', methods=['GET', 'POST'])
def book_room(room_id):
    # Check if the user is logged in
    if 'logged_in_user' not in session:
        return redirect(url_for('login'))  # Redirect to login if not logged in

    room = next((r for r in rooms if r["id"] == room_id), None)
    if request.method == 'POST':
        # Simulating booking a room
        name = request.form['name']
        email = request.form['email']
        date = request.form['date']
        bookings.append({"name": name, "email": email, "room": room["name"], "date": date})
        room["available"] = False  # Mark the room as unavailable
        return redirect(url_for('reservation'))

    return render_template('book_room.html', room=room)


# Route to show user reservations
@app.route('/reservation')
def reservation():
    return render_template('reservation.html', bookings=bookings)

# Route to handle login (simple simulation)
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        # Check if user exists and password is correct
        if email in users and users[email]['password'] == password:
            session['logged_in_user'] = email  # Store the email in the session
            session['user_name'] = users[email]['email'].split('@')[0]  # Store the user's name (you can change this if you have a real name field)
            return redirect(url_for('index'))
        else:
            flash('Invalid email or password. Please try again.', 'danger')
    return render_template('login.html')


# Route to handle registration
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        # Check if the passwords match
        if password != confirm_password:
            flash("Passwords do not match. Please try again.", 'danger')
            return render_template('register.html')
        
        # Check if user already exists
        if email in users:
            flash("Email already registered. Please log in.", 'danger')
            return redirect(url_for('login'))

        # Register the user
        users[email] = {"email": email, "password": password}
        flash("Registration successful! Please log in.", 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

# Route to handle logout
@app.route('/logout')
def logout():
    session.pop('logged_in_user', None)  # Remove logged_in_user from session
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)
