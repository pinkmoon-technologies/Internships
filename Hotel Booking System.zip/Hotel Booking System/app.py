from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for flash messages

# Sample room data (in real application, this would be stored in a database)
rooms = [
    {"id": 1, "name": "Single Room", "price": 100, "available": True, "image": "https://i.ibb.co/pjRtqqcr/l-1.jpg"},
    {"id": 2, "name": "Double Room", "price": 150, "available": True, "image": "https://i.ibb.co/jk5FbRvP/l-2.jpg"},
    {"id": 3, "name": "Triple Room ", "price": 250, "available": True, "image": "https://i.ibb.co/93Hmhgb7/l-6.jpg"},
    {"id": 4, "name": "Queen Room", "price": 450, "available": True, "image": "https://i.ibb.co/JWtJwrVH/l-4.jpg"},
    {"id": 5, "name": "King Room", "price": 550, "available": True, "image": "https://i.ibb.co/8nfxsPkQ/l-5.jpg"},
    {"id": 6, "name": "Suite", "price": 250, "available": True, "image": "https://i.ibb.co/4wrdjbSB/l-3.jpg"}
]

# In-memory "database" for users and bookings
users = {}
bookings = []

@app.route('/')
def index():
    return render_template('index.html', rooms=rooms)

@app.route('/book/<int:room_id>', methods=['GET', 'POST'])
def book_room(room_id):
    if 'logged_in_user' not in session:
        return redirect(url_for('login'))  # Redirect to login if not logged in

    room = next((r for r in rooms if r["id"] == room_id), None)

    # Get already booked date ranges for this room
    booked_dates = [{"start": b["start_date"], "end": b["end_date"]} for b in bookings if b["room"] == room["name"]]

    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        start_date = request.form['start_date']
        end_date = request.form['end_date']

        # Check for overlapping dates
        for b in bookings:
            if b["room"] == room["name"]:
                if (start_date <= b["end_date"] and end_date >= b["start_date"]):
                    flash("This date range is already booked. Please choose another.", "danger")
                    return redirect(url_for('book_room', room_id=room_id))

        bookings.append({"name": name, "email": email, "room": room["name"], "start_date": start_date, "end_date": end_date})
        return redirect(url_for('reservation'))

    return render_template('book_room.html', room=room, booked_dates=booked_dates)

@app.route('/reservation')
def reservation():
    return render_template('reservation.html', bookings=bookings)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        if email in users and users[email]['password'] == password:
            session['logged_in_user'] = email
            session['user_name'] = users[email]['email'].split('@')[0]
            return redirect(url_for('index'))
        else:
            flash('Invalid email or password. Please try again.', 'danger')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            flash("Passwords do not match. Please try again.", 'danger')
            return render_template('register.html')

        if email in users:
            flash("Email already registered. Please log in.", 'danger')
            return redirect(url_for('login'))

        users[email] = {"email": email, "password": password}
        flash("Registration successful! Please log in.", 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('logged_in_user', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
